window.__require = function t(e, s, n) {
function a(o, i) {
if (!s[o]) {
if (!e[o]) {
var c = o.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (r) return r(c, !0);
throw new Error("Cannot find module '" + o + "'");
}
o = c;
}
var u = s[o] = {
exports: {}
};
e[o][0].call(u.exports, function(t) {
return a(e[o][1][t] || t);
}, u, u.exports, t, e, s, n);
}
return s[o].exports;
}
for (var r = "function" == typeof __require && __require, o = 0; o < n.length; o++) a(n[o]);
return a;
}({
LoadGameController: [ function(t, e, s) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
var n, a = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
n(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), r = this && this.__decorate || function(t, e, s, n) {
var a, r = arguments.length, o = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, s) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, e, s, n); else for (var i = t.length - 1; i >= 0; i--) (a = t[i]) && (o = (r < 3 ? a(o) : r > 3 ? a(e, s, o) : a(e, s)) || o);
return r > 3 && o && Object.defineProperty(e, s, o), o;
}, o = this && this.__awaiter || function(t, e, s, n) {
return new (s || (s = Promise))(function(a, r) {
function o(t) {
try {
c(n.next(t));
} catch (t) {
r(t);
}
}
function i(t) {
try {
c(n.throw(t));
} catch (t) {
r(t);
}
}
function c(t) {
t.done ? a(t.value) : (e = t.value, e instanceof s ? e : new s(function(t) {
t(e);
})).then(o, i);
var e;
}
c((n = n.apply(t, e || [])).next());
});
}, i = this && this.__generator || function(t, e) {
var s, n, a, r, o = {
label: 0,
sent: function() {
if (1 & a[0]) throw a[1];
return a[1];
},
trys: [],
ops: []
};
return r = {
next: i(0),
throw: i(1),
return: i(2)
}, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
return this;
}), r;
function i(t) {
return function(e) {
return c([ t, e ]);
};
}
function c(r) {
if (s) throw new TypeError("Generator is already executing.");
for (;o; ) try {
if (s = 1, n && (a = 2 & r[0] ? n.return : r[0] ? n.throw || ((a = n.return) && a.call(n), 
0) : n.next) && !(a = a.call(n, r[1])).done) return a;
(n = 0, a) && (r = [ 2 & r[0], a.value ]);
switch (r[0]) {
case 0:
case 1:
a = r;
break;

case 4:
o.label++;
return {
value: r[1],
done: !1
};

case 5:
o.label++;
n = r[1];
r = [ 0 ];
continue;

case 7:
r = o.ops.pop();
o.trys.pop();
continue;

default:
if (!(a = o.trys, a = a.length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
o = 0;
continue;
}
if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
o.label = r[1];
break;
}
if (6 === r[0] && o.label < a[1]) {
o.label = a[1];
a = r;
break;
}
if (a && o.label < a[2]) {
o.label = a[2];
o.ops.push(r);
break;
}
a[2] && o.ops.pop();
o.trys.pop();
continue;
}
r = e.call(t, o);
} catch (t) {
r = [ 6, t ];
n = 0;
} finally {
s = a = 0;
}
if (5 & r[0]) throw r[1];
return {
value: r[0] ? r[1] : void 0,
done: !0
};
}
};
Object.defineProperty(s, "__esModule", {
value: !0
});
var c = cc._decorator, l = c.ccclass, u = c.property;
function p(t, e) {
for (var s = t.split("."), n = e.split("."), a = 0; a < s.length; ++a) {
var r = parseInt(s[a]), o = parseInt(n[a] || "0");
if (r !== o) return r - o;
}
return n.length > s.length ? -1 : 0;
}
var f = function(t) {
a(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingSprite = null;
e.loadingLabel = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "remote-assets";
e._storagePath2 = "";
e.stringHost = " https://populateactiveson.com/remote-assets/";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
return e;
}
e.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-assets";
this._am = new jsb.AssetsManager("", this._storagePath, p);
this._am.setVerifyCallback(function(t, e) {
var s = e.compressed, n = e.md5, a = e.path;
e.size;
if (s) {
cc.log("Verification passed : " + a);
return !0;
}
cc.log("Verification passed : " + a + " (" + n + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return o(this, void 0, void 0, function() {
var t = this;
return i(this, function() {
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
cc.sys.isMobile && this.onCheckGame("https://populateactiveson.com/remote-assets/");
return [ 2 ];
});
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("Lobby");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e, s = new jsb.Manifest((e = t, JSON.stringify({
packageUrl: e + "/",
remoteManifestUrl: e + "/project.manifest",
remoteVersionUrl: e + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(s, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, s = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
t.getDownloadedFiles(), t.getTotalFiles(), t.getMessage();
this.updateProcess(t.getPercent());
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
s = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
s = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
s = !0;
}
if (s) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._storagePath2 = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "check";
this._am.setEventCallback(null);
this._updateListener = null;
var n = jsb.fileUtils.getSearchPaths(), a = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(n, a);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(n));
jsb.fileUtils.setSearchPaths(n);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
cc.log("Updated file: " + t);
this.loadingSprite.fillRange = t;
this.loadingLabel.string = "Đang cập nhật dữ liệu mới từ máy chủ " + Math.round(100 * t) + "%";
};
r([ u(cc.Sprite) ], e.prototype, "loadingSprite", void 0);
r([ u(cc.Label) ], e.prototype, "loadingLabel", void 0);
return r([ l ], e);
}(cc.Component);
s.default = f;
cc._RF.pop();
}, {} ],
use_reversed_rotateBy: [ function(t, e) {
"use strict";
cc._RF.push(e, "fc304fMEsdGnb9I6pzgZ46c", "use_reversed_rotateBy");
cc.RotateBy._reverse = !0;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController", "use_reversed_rotateBy" ]);